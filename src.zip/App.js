import dummyBikes from './data/dummy-bikes';

function App() {
 
   return (
    <>
      <header >
        <h1>Buy a Bike!</h1>
      </header>
      <main>
        <ul style={{listStyleType:'none'}} >
        {dummyBikes.map((bike) => (
            <li key={bike.id}>
            <img src={bike.image} alt={bike.title} />
                <h2>{bike.title}</h2>
                <p >${bike.price}</p>
                <p>{bike.description}</p>
            <button onClick={(e) =>alert('Clicked')}>Add to Cart</button>
     </li>
      ))}
      </ul>
    </main>
    </>
  );
}

export default App;
