import MyModal from './MyModal';

function App() {
  return (
    <>
        <h2> First Modal </h2>
        <MyModal />
         
    </>
  );
}

export default App;
